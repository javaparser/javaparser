class Qux {
	public static void main(String[] args)
	{
		
	}
}