package io.github.name;

public class MyActivityImpl implements MyActivity {
    @Override
    public MyActivityImpl.MyTimestamps getTimestamps() {
        return timestamps;
    }
}
