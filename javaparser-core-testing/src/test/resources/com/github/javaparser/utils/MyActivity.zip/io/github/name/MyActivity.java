package io.github.name;

public interface MyActivity {
    class MyTimestamps {}
   
    MyTimestamps getTimestamps();
}
