package io.github.name;

public interface MyRichPresence extends MyActivity { }
